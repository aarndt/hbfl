function update (res) {
  return {
    type: 'LEADERBOARDS.UPDATE',
    res
  }
}

export {
  update
}
