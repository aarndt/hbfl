import hamsters from './hamsters'
import races from './races'
import user from './user'
import leaderboards from './leaderboards'
import status from './status'

export default {
  hamsters,
  races,
  user,
  leaderboards,
  status
}
